    MY TEST PACKAGE for GoIT - CLEAN FOLDER
   
    GNU GENERAL PUBLIC LICENSE
                       
